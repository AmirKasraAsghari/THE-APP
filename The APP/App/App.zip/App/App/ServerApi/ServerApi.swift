//
//  ServerApi.swift
//  App
//
//  Created by Sheraz Ahmad on 04/11/2020.
//

import UIKit

class ServerApi {
    
    
    static var Api_Signup = "https://application1122.000webhostapp.com/Admin/signup.php";
    static var Api_Login = "https://application1122.000webhostapp.com/Admin/login.php";
   
    
    static var Api_Update_Password = "https://application1122.000webhostapp.com/Admin/update_password.php";
    
    
    static var Api_Add_New_Question = "https://application1122.000webhostapp.com/Admin/add_new_question.php";
    static var Api_Get_Questions_List = "https://application1122.000webhostapp.com/Admin/question_list.php";
    static var Api_Delete_Question = "https://application1122.000webhostapp.com/Admin/delete_question.php";
    static var Api_Edit_Question = "https://application1122.000webhostapp.com/Admin/update_question.php";
    
    
    
    static var ImageURL = "https://application1122.000webhostapp.com/Customer/Images/";
    static var Api_Get_Customer_List = "https://application1122.000webhostapp.com/Admin/customer_list.php";
    static var Api_Search_Customer = "https://application1122.000webhostapp.com/Admin/search_customer_list.php";
    static var Api_Change_Customer_Status = "https://application1122.000webhostapp.com/Admin/change_customer_status.php";
}
