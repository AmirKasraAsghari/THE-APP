//
//  SignupViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit
import Alamofire
import SwiftyJSON

class SignupViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var tfName: FloatingLabelInput!
    @IBOutlet weak var tfEmail: FloatingLabelInput!
    @IBOutlet weak var tfPassword: FloatingLabelInput!
    @IBOutlet weak var tfConfirmPassword: FloatingLabelInput!
    @IBOutlet weak var btnSignup: UIButton!
    @IBOutlet weak var btnLogin: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        btnSignup.layer.cornerRadius = 10
        btnLogin.layer.borderWidth = 1
        btnLogin.layer.borderColor = UIColor(red: 0.0, green: 0.796, blue: 0.496, alpha: 1.0).cgColor
        btnLogin.layer.cornerRadius = 10
        
        self.hideKeyboard()
        
        tfName.delegate = self
        tfEmail.delegate = self
        tfPassword.delegate = self
        tfConfirmPassword.delegate = self
        
    }
    
    //Dissmiss Keyboard
    func hideKeyboard()
       {
       let tap: UITapGestureRecognizer = UITapGestureRecognizer( target: self, action: #selector(dismissKeyboard))
       view.addGestureRecognizer(tap)
       }
       
    //Dissmiss Keyboard
       @objc func dismissKeyboard()
       {
       view.endEditing(true)
       }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case tfName:
            tfEmail.becomeFirstResponder()
        case tfEmail:
            tfPassword.becomeFirstResponder()
        case tfPassword:
            tfConfirmPassword.becomeFirstResponder()
        default:
            textField.resignFirstResponder()
        }
        return false
    }


    @IBAction func btnSignup(_ sender: Any) {
        //email pattern
        let emailReg = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailReg)
        
        //password pattern
        let passwordReg = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=\\S+$).{6,}$"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passwordReg)
        
        if tfName.text == ""  {
            let alert = UIAlertController(title: "Enter name", message: "To proceed, Please enter your name.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if tfEmail.text == ""  {
            let alert = UIAlertController(title: "Enter email", message: "To proceed, Please enter your Email.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if emailTest.evaluate(with: tfEmail.text) == false {
            let alert = UIAlertController(title: "Email not valid", message: "Please enter a valid email address e.g. abc@example.com", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if tfPassword.text == ""  {
            let alert = UIAlertController(title: "Enter password", message: "To proceed, Please enter your Password.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if passwordTest.evaluate(with: tfPassword.text) == false{
           let alert = UIAlertController(title: "Password not valid", message: "Password must contain 6 characters, including Upper/Lowercase and Number", preferredStyle: UIAlertController.Style.alert)
           alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
           self.present(alert, animated: true, completion: nil)
        }
        
        else if tfConfirmPassword.text == ""  {
            let alert = UIAlertController(title: "Enter confirm password", message: "To proceed, Please enter your Confirm Password.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if tfConfirmPassword.text != tfPassword.text  {
            let alert = UIAlertController(title: "Password not match", message: "To proceed, Please make sure your password and confirm password match.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else{
        hideKeyboard()
        showActivityIndicator()
        registerAdmin()

        }
    }
    
    func registerAdmin(){

        let params: Parameters = [
            "name": tfName.text!,
            "email": tfEmail.text!,
            "password": tfPassword.text!
        ]
        
        AF.request(ServerApi.Api_Signup,method: .post, parameters: params)
                   .responseJSON { response in
                    
                       if let data = response.data {
                           do{
                                let json = try JSON(data: data)
                                let result = json["data"]["result"].string
                            
                                if result == "email already exist"
                                {
                                    DispatchQueue.main.async(execute: {
                                        let alert = UIAlertController(title: "Failed", message: "This email is already existed Please try another one.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                        self.hideActivityIndicator()
                                    })
                                }
                            
                                else if result == "data inserted"
                                {
                                    DispatchQueue.main.async(execute: {
                                        let alert = UIAlertController(title: "Success!", message: "Account successfully created.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                                            self.performSegue(withIdentifier: "Login", sender: self)
                                            }))
                                        self.present(alert, animated: true, completion: nil)
                                        self.hideActivityIndicator()
                                    })
                                    
                                }
                            
                                 }catch{
                                    self.hideActivityIndicator()
                                    print("Unexpected error: \(error).")
                             
                            }
                    }
            }
    }

    
}
