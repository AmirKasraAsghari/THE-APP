//
//  LoginViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit
import Alamofire
import SwiftyJSON

class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var tfEmail: FloatingLabelInput!
    @IBOutlet weak var tfPassword: FloatingLabelInput!
    
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnCreateAccount: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        btnLogin.layer.cornerRadius = 10
        btnCreateAccount.layer.borderWidth = 1
        btnCreateAccount.layer.borderColor = UIColor(red: 0.0, green: 0.796, blue: 0.496, alpha: 1.0).cgColor
        btnCreateAccount.layer.cornerRadius = 10
        
        self.hideKeyboard()
        
        tfEmail.delegate = self
        tfPassword.delegate = self
    }
    

    //Dissmiss Keyboard
    func hideKeyboard()
       {
       let tap: UITapGestureRecognizer = UITapGestureRecognizer( target: self, action: #selector(dismissKeyboard))
       view.addGestureRecognizer(tap)
       }
       
    //Dissmiss Keyboard
       @objc func dismissKeyboard()
       {
       view.endEditing(true)
       }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case tfEmail:
            tfPassword.becomeFirstResponder()
        default:
            textField.resignFirstResponder()
        }
        return false
    }
    
    @IBAction func btnLogin(_ sender: Any) {
        
        let emailReg = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailReg)
        
        if tfEmail.text == ""  {
            let alert = UIAlertController(title: "Enter email", message: "To proceed, Please enter your Email.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if emailTest.evaluate(with: tfEmail.text) == false {
            let alert = UIAlertController(title: "Email not valid", message: "Please enter a valid email address e.g. abc@example.com", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if tfPassword.text == ""  {
            let alert = UIAlertController(title: "Enter password", message: "To proceed, Please enter your Password.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else{
        hideKeyboard()
        showActivityIndicator()
        loginAdmin()

        }
    }
    
    func loginAdmin(){

        let params: Parameters = [
            "email": tfEmail.text!,
            "password": tfPassword.text!
        ]
        
        AF.request(ServerApi.Api_Login,method: .post, parameters: params)
                   .responseJSON { response in
                    
                       if let data = response.data {
                           do{
                                let json = try JSON(data: data)
                                let result = json["data"]["result"].string
                            
                                if result == "no record found"
                                {
                                    DispatchQueue.main.async(execute: {
                                        let alert = UIAlertController(title: "Failed", message: "Incorrect email or password Please recheck.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                        self.hideActivityIndicator()
                                    })
                                }
                            
                                else
                                {
                                    DispatchQueue.main.async(execute: {
                                        let id = json["data"]["id"].string
                                        let name = json["data"]["name"].string
                                        let email = json["data"]["email"].string
                                        
                                        UserDefaults.standard.setloggedInBool(value: true)
                                        UserDefaults.standard.setID(string: id!)
                                        UserDefaults.standard.setName(string: name!)
                                        UserDefaults.standard.setEmail(string: email!)
                                    
                                        self.performSegue(withIdentifier: "Successfully LoggedIn", sender: self)
                                        self.hideActivityIndicator()
                                    })
                                }
                            
                                 }catch{
                                    self.hideActivityIndicator()
                                    print("Unexpected error: \(error).")
                             
                            }
                    }
            }
    }
    
}
