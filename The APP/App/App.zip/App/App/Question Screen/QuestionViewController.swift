//
//  QuestionViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit
import Toast_Swift
import SwiftyJSON
import Alamofire

class QuestionViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var QuestionsTableView: UITableView!
    @IBOutlet weak var btnAddQuestion: UIButton!
    
    var QuestionID: [String] = []
    var Question: [String] = []
    
    //MARK: - Properties
    private var alertController = UIAlertController()
    private var tfQuestion = UITextField()
    var saveAction = UIAlertAction()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        showActivityIndicator()
        Get_Questions_List()
        // Do any additional setup after loading the view.
        QuestionsTableView.dataSource = self
        QuestionsTableView.delegate = self
        QuestionsTableView.tableFooterView = UIView()
        btnAddQuestion.layer.cornerRadius = btnAddQuestion.frame.size.width / 2
        
    }
    
    func Get_Questions_List(){
        
        AF.request(ServerApi.Api_Get_Questions_List,method: .get)
                   .responseJSON { response in
                       if let data = response.data {
                           do{
                                let json = try JSON(data: data)
                                let result = json["data"]["result"].string
                            print(json)
                                if result == "no record found"
                                {
                                    self.QuestionID.removeAll()
                                    self.Question.removeAll()
                                    DispatchQueue.main.async(execute: {
                                        let alert = UIAlertController(title: "No Questions found", message: "Please add some questions.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                        self.QuestionsTableView.reloadData()
                                        self.hideActivityIndicator()
                                        
                                    })
                                    
                                }else{
                                    self.QuestionID.removeAll()
                                    self.Question.removeAll()
                                    for (_, subJson) in json["data"]["question"] {
                                        let question_id = subJson["question_id"].string
                                        let question = subJson["question"].string
                                        
                                        self.QuestionID.append(question_id!)
                                        self.Question.append(question!)
                                    }
                                    
                                    self.QuestionsTableView.reloadData()
                                    self.hideActivityIndicator()
                                        
                                }
                            
                                 }catch{
                                    self.hideActivityIndicator()
                                    print("Unexpected error: \(error).")
                             
                            }
                    }
            }
    }
    
    
    
    @IBAction func btnAddQuestion(_ sender: Any) {
        let alertController = UIAlertController(title: "Add New Question", message: "", preferredStyle: UIAlertController.Style.alert)
        alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Type Question"
            }
        tfQuestion = alertController.textFields![0] as UITextField
        
        saveAction = UIAlertAction(title: "Add", style: UIAlertAction.Style.default, handler: { alert -> Void in
            print(self.tfQuestion.text!)
                self.showActivityIndicator()
                self.Add_New_Question()
            })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: {
                (action : UIAlertAction!) -> Void in })
        
         tfQuestion.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
            alertController.addAction(cancelAction)
            alertController.addAction(saveAction)
            saveAction.isEnabled=false
            
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
    @objc func textFieldDidChange(textField: UITextField){
            if textField.text != "" {
                saveAction.isEnabled = true
            }
            else {
                saveAction.isEnabled = false
            }
        }
    
    
    
    func Add_New_Question(){
        let params: Parameters = [
            "question": tfQuestion.text!
        ]
        
        AF.request(ServerApi.Api_Add_New_Question,method: .post, parameters: params)
                   .responseJSON { response in
                       if let data = response.data {
                           do{
                                let json = try JSON(data: data)
                                let result = json["data"]["result"].string
                                print(json)
                                if result == "question added"
                                {
                                    DispatchQueue.main.async(execute: {
                                        self.Get_Questions_List()
                                        self.view.makeToast("Question successfully added")
                                        //self.hideActivityIndicator()
                                    })
                                    
                                }else{
                                    DispatchQueue.main.async(execute: {
                                        self.view.makeToast("Please try again something went wrong")
                                        self.hideActivityIndicator()
                                    })
                                }
                            
                                 }catch{
                                    self.hideActivityIndicator()
                                    print("Unexpected error: \(error).")
                             
                            }
                    }
            }
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return QuestionID.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! QuestionsTableViewCell
        
        cell.lblQuestion.text = Question[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        // action one
    let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
            self.Delete_Question(ID: self.QuestionID[indexPath.row])
            print("Delete tapped")
        })
        
        deleteAction.backgroundColor = UIColor.init(red: 0.86, green: 0.322, blue: 0.294, alpha: 1.0)
        
        // action two
    let editAction = UITableViewRowAction(style: .default, title: "Edit", handler: { (action, indexPath) in
           //self.Edit_Question(ID: self.QuestionID[indexPath.row])
        let alertController = UIAlertController(title: "Edit Question", message: "", preferredStyle: UIAlertController.Style.alert)
        alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Type Question"
            }
        self.tfQuestion = alertController.textFields![0] as UITextField
        self.tfQuestion.text = self.Question[indexPath.row]
        
        self.saveAction = UIAlertAction(title: "Save", style: UIAlertAction.Style.default, handler: { alert -> Void in
            print(self.tfQuestion.text!)
                self.showActivityIndicator()
            self.Edit_Question(ID: self.QuestionID[indexPath.row], Question: self.Question[indexPath.row])
            })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: {
                (action : UIAlertAction!) -> Void in })
        
        self.tfQuestion.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: .editingChanged)
        
        alertController.addAction(cancelAction)
        alertController.addAction(self.saveAction)
            
        self.present(alertController, animated: true, completion: nil)
           print("Edit tapped")
        })
        editAction.backgroundColor = UIColor.init(red: 0.24, green: 0.542, blue: 0.801, alpha: 1.0)
        
        return [deleteAction, editAction]
    }
    
    
    func Delete_Question(ID: String){
        let params: Parameters = [
            "id": ID
        ]
        AF.request(ServerApi.Api_Delete_Question,method: .post, parameters: params)
                   .responseJSON { response in
                       if let data = response.data {
                           do{
                                // Get json data
                            let json = try JSON(data: data)
                            let result = json["data"]["result"].string
                            if result == "Question successfully deleted"
                            {
                                DispatchQueue.main.async(execute: {
                                    self.Get_Questions_List()
                                    self.view.makeToast("Question successfully deleted")
                                    //self.hideActivityIndicator()
                                })
                                
                            }else{
                                DispatchQueue.main.async(execute: {
                                    self.view.makeToast("Please try again something went wrong")
                                    self.hideActivityIndicator()
                                })
                            }
                            
                            }catch{
                               print("Unexpected error: \(error).")
                        
                           }
                       }
               }
    }
    
    func Edit_Question(ID: String, Question: String){
        let params: Parameters = [
            "id": ID,
            "question": tfQuestion.text!
        ]
        AF.request(ServerApi.Api_Edit_Question,method: .post, parameters: params)
                   .responseJSON { response in
                       if let data = response.data {
                           do{
                                // Get json data
                            let json = try JSON(data: data)
                            let result = json["data"]["result"].string
                            if result == "Question successfully updated"
                            {
                                DispatchQueue.main.async(execute: {
                                    self.Get_Questions_List()
                                    self.view.makeToast("Question successfully updated")
                                    //self.hideActivityIndicator()
                                })
                                
                            }else{
                                DispatchQueue.main.async(execute: {
                                    self.view.makeToast("Please try again something went wrong")
                                    self.hideActivityIndicator()
                                })
                            }
                            
                            }catch{
                               print("Unexpected error: \(error).")
                        
                           }
                       }
               }
    }
}
