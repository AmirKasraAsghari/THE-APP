//
//  LaunchScreenViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit
import iLoader

extension UIViewController {
    
    func showActivityIndicator() {
        iLoader.shared.loaderTitle = "Please Wait..."
        iLoader.shared.show()
         
    }

    func hideActivityIndicator() {
        iLoader.shared.hide()
    }
}

class LaunchScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let seconds = 3.0
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            // Put your code which should be executed with a delay here
            if UserDefaults.standard.isloggedInBool() == true{
                let main = UIStoryboard(name: "Main", bundle: nil)
                let login = main.instantiateViewController(withIdentifier: "TabBarVC")
                login.modalPresentationStyle = UIModalPresentationStyle.fullScreen
                self.present(login,animated: true,completion: nil)
            }
            else{
                let main = UIStoryboard(name: "Main", bundle: nil)
                let login = main.instantiateViewController(withIdentifier: "LoginVC")
                login.modalPresentationStyle = UIModalPresentationStyle.fullScreen
                self.present(login,animated: true,completion: nil)
            }
            
        }
    }
    

 

}
