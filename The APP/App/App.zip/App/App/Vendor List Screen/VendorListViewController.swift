//
//  VendorListViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit

class VendorListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    

    @IBOutlet weak var viewFilter: UIView!
    @IBOutlet weak var vendorSearchBar: UISearchBar!
    @IBOutlet weak var VendorListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
            VendorListTableView.dataSource = self
            VendorListTableView.delegate = self
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! VendorListTableViewCell
        
        return cell
    }
 
    @IBAction func btnFilter(_ sender: Any) {
    }
    
}
