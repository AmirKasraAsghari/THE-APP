//
//  VisitDetailViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 02/11/2020.
//

import UIKit

class VisitDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var VisitDetailTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        VisitDetailTableView.dataSource = self
        VisitDetailTableView.delegate = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! VisitDetailTableViewCell
        
        return cell
    }

  

}
