//
//  CustomerDetailViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit

class CustomerDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var ImageViewProfile: UIImageView!
    @IBOutlet weak var lblCustomerName: UILabel!
    @IBOutlet weak var lblTotalRewardPoints: UILabel!
    @IBOutlet weak var viewBackground: UIView!
    
    @IBOutlet weak var CustomerDetailTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        CustomerDetailTableView.dataSource = self
        CustomerDetailTableView.delegate = self
        
        viewBackground.layer.cornerRadius=10
        ImageViewProfile.layer.borderWidth = 1.0
        ImageViewProfile.layer.masksToBounds = false
        ImageViewProfile.layer.borderColor = UIColor.white.cgColor
        ImageViewProfile.layer.cornerRadius = ImageViewProfile.frame.size.width / 2
        ImageViewProfile.clipsToBounds = true
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! CustomerDetailTableViewCell
        
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "Visit Details", sender: self)
  
    }
    

}
