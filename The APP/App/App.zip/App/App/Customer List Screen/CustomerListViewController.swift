//
//  CustomerListViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit
import Alamofire
import SwiftyJSON
import Kingfisher

class CustomerListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {

    var Customer_ID: [String] = []
    var Customer_Name: [String] = []
    var Customer_Email: [String] = []
    var Customer_Phone: [String] = []
    var Customer_Image: [String] = []
    var Customer_Status: [String] = []
    
    var status: String!
    @IBOutlet weak var ViewFilter: UIView!
    @IBOutlet weak var customerSearchBar: UISearchBar!
    
    @IBOutlet weak var CustomerListTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        showActivityIndicator()
        Get_Customer_List()
        // Do any additional setup after loading the view.
        CustomerListTableView.dataSource = self
        CustomerListTableView.delegate = self
        CustomerListTableView.tableFooterView = UIView()
        hideKeyboard()
        customerSearchBar.delegate = self
        
    }
    
    //Dissmiss Keyboard
       func hideKeyboard()
          {
          let tap: UITapGestureRecognizer = UITapGestureRecognizer( target: self, action: #selector(dismissKeyboard))
          customerSearchBar.addGestureRecognizer(tap)
          }
          
       //Dissmiss Keyboard
          @objc func dismissKeyboard()
          {
          self.customerSearchBar.endEditing(true)
          }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar){
    self.customerSearchBar.endEditing(true)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        print(searchText)
        Search_Customer(SeachText: searchText)
    }
    
    
    func Search_Customer(SeachText: String){
        let params: Parameters = [
            "email": SeachText
        ]
        
        AF.request(ServerApi.Api_Search_Customer,method: .post, parameters: params)
                   .responseJSON { response in
                       if let data = response.data {
                           do{
                                let json = try JSON(data: data)
                                let result = json["data"]["result"].string
                            print(json)
                                if result == "no record found"
                                {
                                    self.Customer_ID.removeAll()
                                    self.Customer_Name.removeAll()
                                    self.Customer_Email.removeAll()
                                    self.Customer_Phone.removeAll()
                                    self.Customer_Image.removeAll()
                                    self.Customer_Status.removeAll()
                                    
                                    DispatchQueue.main.async(execute: {
                                        let alert = UIAlertController(title: nil, message: "No Customer Found.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                        self.CustomerListTableView.reloadData()
                                        self.hideActivityIndicator()
                                        
                                    })
                                    
                                }else{
                                    self.Customer_ID.removeAll()
                                    self.Customer_Name.removeAll()
                                    self.Customer_Email.removeAll()
                                    self.Customer_Phone.removeAll()
                                    self.Customer_Image.removeAll()
                                    self.Customer_Status.removeAll()
                                    
                                    for (_, subJson) in json["data"]["customer"] {
                                        let id = subJson["customer_id"].string
                                        let name = subJson["customer_name"].string
                                        let email = subJson["customer_email"].string
                                        let phone = subJson["customer_phone"].string
                                        let image = subJson["customer_image"].string
                                        let status = subJson["customer_status"].string
                                        
                                        self.Customer_ID.append(id!)
                                        self.Customer_Name.append(name!)
                                        self.Customer_Email.append(email!)
                                        self.Customer_Phone.append(phone!)
                                        self.Customer_Image.append(image!)
                                        self.Customer_Status.append(status!)
                                    }
                                    print(self.Customer_Status)
                                    self.CustomerListTableView.reloadData()
                                    self.hideActivityIndicator()
                                        
                                }
                            
                                 }catch{
                                    self.hideActivityIndicator()
                                    print("Unexpected error: \(error).")
                             
                            }
                    }
            }
    }
    
    
    func Get_Customer_List(){
        AF.request(ServerApi.Api_Get_Customer_List,method: .get)
                   .responseJSON { response in
                       if let data = response.data {
                           do{
                                let json = try JSON(data: data)
                                let result = json["data"]["result"].string
                            print(json)
                                if result == "no record found"
                                {
                                    self.Customer_ID.removeAll()
                                    self.Customer_Name.removeAll()
                                    self.Customer_Email.removeAll()
                                    self.Customer_Phone.removeAll()
                                    self.Customer_Image.removeAll()
                                    self.Customer_Status.removeAll()
                                    
                                    DispatchQueue.main.async(execute: {
                                        let alert = UIAlertController(title: nil, message: "No Customer Found.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                        self.CustomerListTableView.reloadData()
                                        self.hideActivityIndicator()
                                        
                                    })
                                    
                                }else{
                                    self.Customer_ID.removeAll()
                                    self.Customer_Name.removeAll()
                                    self.Customer_Email.removeAll()
                                    self.Customer_Phone.removeAll()
                                    self.Customer_Image.removeAll()
                                    self.Customer_Status.removeAll()
                                    
                                    for (_, subJson) in json["data"]["customer"] {
                                        let id = subJson["customer_id"].string
                                        let name = subJson["customer_name"].string
                                        let email = subJson["customer_email"].string
                                        let phone = subJson["customer_phone"].string
                                        let image = subJson["customer_image"].string
                                        let status = subJson["customer_status"].string
                                        
                                        self.Customer_ID.append(id!)
                                        self.Customer_Name.append(name!)
                                        self.Customer_Email.append(email!)
                                        self.Customer_Phone.append(phone!)
                                        self.Customer_Image.append(image!)
                                        self.Customer_Status.append(status!)
                                    }
                                    print(self.Customer_Status)
                                    self.CustomerListTableView.reloadData()
                                    self.hideActivityIndicator()
                                        
                                }
                            
                                 }catch{
                                    self.hideActivityIndicator()
                                    print("Unexpected error: \(error).")
                             
                            }
                    }
            }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Customer_ID.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! CustomerListTableViewCell
        //self.customerSearchBar.endEditing(true)
        
        cell.ImageViewProfile.layer.borderWidth = 1.0
        cell.ImageViewProfile.layer.masksToBounds = false
        cell.ImageViewProfile.layer.borderColor = UIColor.white.cgColor
        cell.ImageViewProfile.layer.cornerRadius = cell.ImageViewProfile.frame.size.width / 2
        cell.ImageViewProfile.clipsToBounds = true
        
        let url = URL(string: "\(ServerApi.ImageURL)\(Customer_Image[indexPath .row])" )
        cell.ImageViewProfile.kf.setImage(with: url)
        
        cell.lblName.text = Customer_Name[indexPath.row]
        cell.lblEmail.text = Customer_Email[indexPath.row]
        cell.lblPhone.text = Customer_Phone[indexPath.row]
        
        if Customer_Status[indexPath.row] == "1"{
            cell.SCBlockUnblock.selectedSegmentIndex = 1
        cell.SCBlockUnblock.selectedSegmentTintColor = UIColor.init(red: 0.428, green: 0.863, blue: 0.373, alpha: 1.0)
        }else if Customer_Status[indexPath.row] == "0"{
            cell.SCBlockUnblock.selectedSegmentIndex = 0
            cell.SCBlockUnblock.selectedSegmentTintColor = UIColor.init(red: 0.867, green: 0.867, blue: 0.867, alpha: 1.0)
        }
        
        cell.SCBlockUnblock.addTarget(self, action:#selector(CustomerListViewController.handleSwipes(_:)), for: .allEvents)
        
        return cell
    }
    
    @objc func handleSwipes(_ sender: UIButton){
        if let cell = sender.superview?.superview as? CustomerListTableViewCell {
            let indexPath = CustomerListTableView.indexPath(for: cell)
        let index : Int = indexPath!.row
        if cell.SCBlockUnblock.selectedSegmentIndex == 1
            {
            cell.SCBlockUnblock.selectedSegmentTintColor = UIColor.init(red: 0.428, green: 0.863, blue: 0.373, alpha: 1.0)
            Customer_Status[index] = "1"
            status = "1"
            ChangeCustomerStatus(id: self.Customer_ID[indexPath!.row])
            }

            if cell.SCBlockUnblock.selectedSegmentIndex == 0
            {
                cell.SCBlockUnblock.selectedSegmentTintColor = UIColor.init(red: 0.867, green: 0.867, blue: 0.867, alpha: 1.0)
                Customer_Status[index] = "0"
                status = "0"
            ChangeCustomerStatus(id: self.Customer_ID[indexPath!.row])
            }
        }
    }
    
    func ChangeCustomerStatus(id: String){
        
        let params: Parameters = [
            "id": id,
            "status": status!
        ]
        
        AF.request("\(ServerApi.Api_Change_Customer_Status)",method: .post, parameters: params)
                   .responseJSON { response in
                       if let data = response.data {
                           do{
                                // Get json data
                            let json = try JSON(data: data)
                            
                            let result = json["data"]["result"].string
                            if result == "Status successfully updated"
                            {
                                DispatchQueue.main.async(execute: {
                                    self.Get_Customer_List()
                                    //self.hideActivityIndicator()
                                })
                                
                            }else{
                                DispatchQueue.main.async(execute: {
                                    self.hideActivityIndicator()
                                })
                            }
                                
                
                            
                            }catch{
                               print("Unexpected error: \(error).")
                        
                           }
                       }
               }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "Customer Details", sender: self)
  
    }
    @IBAction func btnFilter(_ sender: Any) {
    }
    

}
