//
//  CustomerListTableViewCell.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit

class CustomerListTableViewCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    @IBOutlet weak var ImageViewProfile: UIImageView!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var SCBlockUnblock: UISegmentedControl!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

   

}
