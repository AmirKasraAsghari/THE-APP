//
//  HomeViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var viewVendorList: UIView!
    @IBOutlet weak var viewCustomerList: UIView!
    @IBOutlet weak var viewVendorRequest: UIView!
    @IBOutlet weak var viewQuestionnairedList: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        viewVendorList.layer.cornerRadius=10
        viewCustomerList.layer.cornerRadius=10
        viewVendorRequest.layer.cornerRadius=10
        viewQuestionnairedList.layer.cornerRadius=10
        
        let VendorList = UITapGestureRecognizer(target: self, action: #selector(VendorListTap))
        viewVendorList.addGestureRecognizer(VendorList)
        
        let CustomerList = UITapGestureRecognizer(target: self, action: #selector(CustomerListTap))
        viewCustomerList.addGestureRecognizer(CustomerList)
        
        let VendorRequest = UITapGestureRecognizer(target: self, action: #selector(VendorRequestTap))
        viewVendorRequest.addGestureRecognizer(VendorRequest)
        
        let QuestionnaireList = UITapGestureRecognizer(target: self, action: #selector(QuestionnaireListTap))
        viewQuestionnairedList.addGestureRecognizer(QuestionnaireList)
    }
    
    @objc func VendorListTap() {
        self.performSegue(withIdentifier: "Vendor List", sender: self)
    }
    
    @objc func CustomerListTap() {
            self.performSegue(withIdentifier: "Customer List", sender: self)
    }
    
    @objc func VendorRequestTap() {
            self.performSegue(withIdentifier: "Vendor Requests", sender: self)
    }
    
    @objc func QuestionnaireListTap() {
            self.performSegue(withIdentifier: "Questionnaires List", sender: self)
    }
 

}
