//
//  UserDefaults.swift
//  App
//
//  Created by Sheraz Ahmad on 04/11/2020.
//

import UIKit

extension UserDefaults{

    //Check Login
    func setloggedInBool(value: Bool) {
        set(value, forKey: UserDefaultsKeys.loggedIn.rawValue)
        //synchronize()
    }

    func isloggedInBool()-> Bool {
        return bool(forKey: UserDefaultsKeys.loggedIn.rawValue)
    }
    //save id
    func setID(string: String){
        set(string, forKey: UserDefaultsKeys.ID.rawValue)
        //synchronize()
    }
    
    //Retrieve ID
    func getID() -> String{
        return UserDefaults.standard.string(forKey: UserDefaultsKeys.ID.rawValue)!
    }
        
    //save first name
    func setName(string: String){
        set(string, forKey: UserDefaultsKeys.name.rawValue)
        //synchronize()
    }

    //Retrieve first name
    func getName() -> String{
        return UserDefaults.standard.string(forKey: UserDefaultsKeys.name.rawValue)!
    }
        
        
    //save email name
    func setEmail(string: String){
        set(string, forKey: UserDefaultsKeys.Email.rawValue)
        //synchronize()
    }

    //Retrieve email name
    func getEmail() -> String{
            return UserDefaults.standard.string(forKey: UserDefaultsKeys.Email.rawValue)!
    }

}

    enum UserDefaultsKeys : String {
        case loggedIn
        case ID
        case name
        case Email
    }
