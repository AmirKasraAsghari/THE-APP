//
//  ProfileViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit
import Alamofire
import SwiftyJSON

class ProfileViewController: UIViewController {

    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    
    @IBOutlet weak var btnChangePassword: UIButton!
    
    @IBOutlet weak var btnLogout: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        btnLogout.layer.cornerRadius = 10
        tfName.text = UserDefaults.standard.getName()
        tfEmail.text = UserDefaults.standard.getEmail()
    }
    

    @IBAction func btnLogout(_ sender: Any) {
        UserDefaults.standard.setloggedInBool(value: false)
        let main = UIStoryboard(name: "Main", bundle: nil)
        let login = main.instantiateViewController(withIdentifier: "LoginVC")
        login.modalPresentationStyle = UIModalPresentationStyle.fullScreen
        self.present(login,animated: true,completion: nil)
    }
    

    
    
   
}
