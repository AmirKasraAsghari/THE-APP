//
//  ChangePasswordViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit
import Alamofire
import SwiftyJSON
class ChangePasswordViewController: UIViewController {

    @IBOutlet weak var tfOldPassword: UITextField!
    @IBOutlet weak var tfNewPassword: UITextField!
    @IBOutlet weak var tfReEnterNewPassword: UITextField!
    
    @IBOutlet weak var btnUpdatePassword: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        btnUpdatePassword.layer.cornerRadius = 10
        
        self.hideKeyboard()
    }
    
    
    //Dissmiss Keyboard
    func hideKeyboard()
       {
       let tap: UITapGestureRecognizer = UITapGestureRecognizer( target: self, action: #selector(dismissKeyboard))
       view.addGestureRecognizer(tap)
       }
       
    //Dissmiss Keyboard
       @objc func dismissKeyboard()
       {
       view.endEditing(true)
       }
    

    @IBAction func btnUpdatePassword(_ sender: Any) {
        if tfOldPassword.text == ""  {
            let alert = UIAlertController(title: "Enter password", message: "To proceed, Please enter your old password.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if tfNewPassword.text == ""  {
            let alert = UIAlertController(title: "Enter confirm password", message: "To proceed, Please enter your New password.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if tfReEnterNewPassword.text == ""  {
            let alert = UIAlertController(title: "Enter confrim new password", message: "To proceed, Please re-enter your new password.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if tfReEnterNewPassword.text != tfNewPassword.text  {
            let alert = UIAlertController(title: "Password not match", message: "To proceed, Please make sure your new password and confirm new password match.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        else{
            hideKeyboard()
            showActivityIndicator()
            UpdatePassword()
            
        }
    }
    
    func UpdatePassword(){

        let params: Parameters = [
            "id": UserDefaults.standard.getID(),
            "old_password": tfOldPassword.text!,
            "new_password": tfNewPassword.text!
        ]
        
        AF.request(ServerApi.Api_Update_Password,method: .post, parameters: params)
                   .responseJSON { response in
                    
                       if let data = response.data {
                           do{
                                let json = try JSON(data: data)
                                let result = json["data"]["result"].string
                            
                                if result == "old password incorrect"
                                {
                                    DispatchQueue.main.async(execute: {
                                        let alert = UIAlertController(title: "Failed", message: "Old password is incorrect Please try again.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                        self.hideActivityIndicator()
                                    })
                                }
                            
                                else
                                {
                                    DispatchQueue.main.async(execute: {
                                        let alert = UIAlertController(title: "Success!", message: "Password updated successfully.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                                            self.navigationController?.popViewController(animated: true)
                                            }))
                                        self.present(alert, animated: true, completion: nil)
                                        self.hideActivityIndicator()
                                        
                                        
                                    })
                                }
                            
                                 }catch{
                                    self.hideActivityIndicator()
                                    print("Unexpected error: \(error).")
                             
                            }
                    }
            }
    }
    
    
}
