//
//  VendorRequestViewController.swift
//  App
//
//  Created by Sheraz Ahmad on 01/11/2020.
//

import UIKit

class VendorRequestViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var vendorRequestSearchBar: UISearchBar!
    @IBOutlet weak var VendorRequestTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
            VendorRequestTableView.dataSource = self
            VendorRequestTableView.delegate = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return 10
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell=tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! VendorRequestTableViewCell
           
           return cell
       }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        // action one
    let deleteAction = UITableViewRowAction(style: .default, title: "Reject", handler: { (action, indexPath) in
            print("Reject tapped")
        })
        
        deleteAction.backgroundColor = UIColor.init(red: 0.86, green: 0.322, blue: 0.294, alpha: 1.0)
        
        // action two
    let editAction = UITableViewRowAction(style: .default, title: "Approve", handler: { (action, indexPath) in
            print("Approve tapped")
        })
        editAction.backgroundColor = UIColor.init(red: 0.0, green: 0.796, blue: 0.496, alpha: 1.0)
        
        return [deleteAction, editAction]
    }

}
